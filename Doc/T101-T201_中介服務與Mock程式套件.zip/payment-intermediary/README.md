# T101 / T102 / T112 / T201 中介服務與 Mock

此套件包含：

- `src/`：Java 17 / Spring Boot 3 中介服務框架
- `mock-server/`：僅使用 Python 標準函式庫、可立即啟動的 Mock Server
- `samples/source/`：使用者提供的 8 份原始 JSON（不修改）
- `samples/requests/`、`samples/responses/`：可執行且已填值的測試電文
- `docs/`：更新後的系統設計規格書

## 已處理的規格差異

1. 原始 `T102Request.json` 的 `HEAD.prsCode` 為 `T101`；可執行範例已依檔名與交易用途校正為 `T102`。
2. 原始 `T112Response.json` 僅有 `HEAD`；Mock 依此回傳 head-only response，不擅自新增 `BODY`。
3. Wire format 保留大寫 `HEAD` / `BODY` / `QUERYHEAD` / `QUERYDETAIL` / `PAYHEAD` / `PAYDETAIL`。
4. 服務使用 URL 與 `HEAD.prsCode` 雙重檢核，避免送錯電文。

## 立即執行 Mock（不需第三方套件）

```bash
python3 mock-server/server.py --port 8080
# 另一個終端機
./scripts/demo.sh
```

自動測試四支電文：

```bash
python3 mock-server/test_mock.py
```

## 啟動 Spring Boot 中介服務

需求：Java 17、Maven 3.9+

```bash
mvn test
mvn spring-boot:run
./scripts/demo.sh
```

預設 `bridge.mode=mock`，可用環境變數覆寫：

```bash
BRIDGE_MODE=mock SERVER_PORT=8080 mvn spring-boot:run
```

## API

```text
POST /api/v1/messages/T101
POST /api/v1/messages/T102
POST /api/v1/messages/T112
POST /api/v1/messages/T201
GET  /actuator/health      # Spring Boot
GET  /health               # Python Mock
```

## 串接正式票交主機時

新增 `ClearingGatewayClient` 的正式實作（HTTP/TCP/MQ 依實際介面），並以 `bridge.mode=live` 切換。正式版應補上：連線逾時、重試白名單、斷路器、TLS/mTLS、祕密管理、稽核遮罩與交易冪等儲存。
