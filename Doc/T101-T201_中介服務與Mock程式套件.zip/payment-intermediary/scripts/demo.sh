#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${BASE_URL:-http://127.0.0.1:8080}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for code in T101 T102 T112 T201; do
  echo "=== $code ==="
  curl --fail --silent --show-error -H 'Content-Type: application/json' \
    --data-binary "@$ROOT/samples/requests/${code}Request.json" \
    "$BASE_URL/api/v1/messages/$code"
  echo
done
