package tw.com.example.paymentbridge;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.StandardCharsets;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class MessageControllerTest {
    @Autowired MockMvc mockMvc;

    @ParameterizedTest
    @ValueSource(strings = {"T101", "T102", "T112", "T201"})
    void exchangesEachSupportedMessage(String code) throws Exception {
        var resource = new ClassPathResource("mock/requests/" + code + "Request.json");
        String request = new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        mockMvc.perform(post("/api/v1/messages/{code}", code)
                .contentType(MediaType.APPLICATION_JSON).content(request))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.HEAD.prsCode").value(code))
                .andExpect(jsonPath("$.HEAD.icChkCode").value("0000"));
    }
}
