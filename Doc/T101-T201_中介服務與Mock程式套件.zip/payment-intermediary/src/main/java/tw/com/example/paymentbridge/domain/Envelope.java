package tw.com.example.paymentbridge.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record Envelope<T>(
        @JsonProperty("HEAD") MessageHead head,
        @JsonProperty("BODY") T body) { }
