package tw.com.example.paymentbridge.domain;

import java.util.List;

public final class T102Models {
    private T102Models() { }

    public record PayRequestHead(String pendingNo, String pendingNotAfter,
            Long totalCount, Long totalAmount, Long totalFee, String outBankId,
            String memberId, String payDatetime, String checkType, String billType,
            String deviceId, String carrierType, String carrierNo, String mobile,
            String accountNo, String cardNo, String merchantId, String mccCode,
            String terminal, String email, String querySeqNo) { }

    public record PayRequestDetail(String detailNo, Long txnAmount,
            String billData, String billBatch) { }

    public record RequestBody(PayRequestHead PAYHEAD,
            List<PayRequestDetail> PAYDETAIL, String key) { }

    public record PayResponseHead(Long totalCount, Long totalAmount,
            Long tPaidCount, Long tPaidAmount, String mFlag) { }

    public record PayResponseDetail(String detailNo, Long txnAmount,
            String billData, String billBatch, String rtnCode, String rtnCodeDesc,
            String efcsSeqNo, String efcsTxnDatetime, String billDate, Long payDataNo,
            String writeOffName1, String writeOffData1,
            String writeOffName2, String writeOffData2,
            String writeOffName3, String writeOffData3,
            String writeOffName4, String writeOffData4,
            String writeOffName5, String writeOffData5) { }

    public record ResponseBody(PayResponseHead PAYHEAD,
            List<PayResponseDetail> PAYDETAIL, String key) { }
}
