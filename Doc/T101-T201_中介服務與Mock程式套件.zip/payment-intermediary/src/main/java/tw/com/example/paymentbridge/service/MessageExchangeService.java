package tw.com.example.paymentbridge.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;
import tw.com.example.paymentbridge.client.ClearingGatewayClient;
import tw.com.example.paymentbridge.domain.PrsCode;
import tw.com.example.paymentbridge.error.ProtocolException;

@Service
public class MessageExchangeService {
    private final ClearingGatewayClient gatewayClient;

    public MessageExchangeService(ClearingGatewayClient gatewayClient) {
        this.gatewayClient = gatewayClient;
    }

    public JsonNode exchange(String pathPrsCode, JsonNode request) {
        PrsCode code = PrsCode.parse(pathPrsCode);
        validate(code, request);
        return gatewayClient.exchange(code, request);
    }

    private static void validate(PrsCode code, JsonNode request) {
        if (request == null || !request.isObject())
            throw new ProtocolException("JSON object is required");
        JsonNode head = request.get("HEAD");
        if (head == null || !head.isObject())
            throw new ProtocolException("HEAD object is required");
        String actual = head.path("prsCode").asText("");
        if (!code.name().equals(actual))
            throw new ProtocolException("Path prsCode " + code + " does not match HEAD.prsCode " + actual);
        if (request.get("BODY") == null || !request.get("BODY").isObject())
            throw new ProtocolException("BODY object is required for requests");
    }
}
