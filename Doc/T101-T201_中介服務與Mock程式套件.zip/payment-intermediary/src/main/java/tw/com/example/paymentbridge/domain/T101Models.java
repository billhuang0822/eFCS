package tw.com.example.paymentbridge.domain;

import java.util.List;

public final class T101Models {
    private T101Models() { }

    public record RequestBody(String queryType, String queryData1, String queryData2,
            String queryData3, String queryData4, String queryData5,
            String eBillSn, String outBankId, String key) { }

    public record QueryHead(String pendingNo, String pendingNotAfter, Long totalCount,
            Long totalAmount, String billerNickName, String bTypeClassName,
            String billType, String wFlag, String mFlag, String returnUrl,
            String querySeqNo) { }

    public record QueryDetail(String queryDetailNo, String queryIsPay,
            String queryBillData, String queryBillBatch, Long queryAmount,
            Long queryHC1, String queryDate, Long queryDataNo,
            String queryDispName1, String queryDispData1,
            String queryDispName2, String queryDispData2,
            String queryDispName3, String queryDispData3,
            String queryDispName4, String queryDispData4,
            String queryDispName5, String queryDispData5,
            String queryDispName6, String queryDispData6,
            String queryDispName7, String queryDispData7,
            String queryDispName8, String queryDispData8,
            String queryDispName9, String queryDispData9,
            String queryDispName10, String queryDispData10) { }

    public record ResponseBody(QueryHead QUERYHEAD, List<QueryDetail> QUERYDETAIL, String key) { }
}
