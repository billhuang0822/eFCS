package tw.com.example.paymentbridge.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import tw.com.example.paymentbridge.domain.PrsCode;

@Component
@ConditionalOnProperty(name = "bridge.mode", havingValue = "mock", matchIfMissing = true)
public class MockClearingGatewayClient implements ClearingGatewayClient {
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    private final ObjectMapper mapper;

    public MockClearingGatewayClient(ObjectMapper mapper) { this.mapper = mapper; }

    @Override
    public JsonNode exchange(PrsCode prsCode, JsonNode request) {
        String resource = "/mock/" + prsCode + "Response.json";
        try (InputStream in = getClass().getResourceAsStream(resource)) {
            if (in == null) throw new IllegalStateException("Missing mock fixture: " + resource);
            ObjectNode response = (ObjectNode) mapper.readTree(in);
            ObjectNode responseHead = (ObjectNode) response.path("HEAD");
            JsonNode requestHead = request.path("HEAD");
            copyIfPresent(requestHead, responseHead, "txnChannel");
            copyIfPresent(requestHead, responseHead, "txnNo");
            copyIfPresent(requestHead, responseHead, "billerId");
            copyIfPresent(requestHead, responseHead, "bTypeClass");
            responseHead.put("prsCode", prsCode.name());
            responseHead.put("txnDataTime", LocalDateTime.now().format(TS));
            responseHead.put("icChkCode", "0000");
            responseHead.put("icChkDesc", "SUCCESS");
            return response;
        } catch (IOException ex) {
            throw new IllegalStateException("Cannot load mock response for " + prsCode, ex);
        }
    }

    private static void copyIfPresent(JsonNode source, ObjectNode target, String field) {
        JsonNode value = source.get(field);
        if (value != null && !value.isNull()) target.set(field, value);
    }
}
