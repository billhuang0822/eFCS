package tw.com.example.paymentbridge.controller;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tw.com.example.paymentbridge.service.MessageExchangeService;

@RestController
@RequestMapping("/api/v1/messages")
public class MessageController {
    private final MessageExchangeService service;

    public MessageController(MessageExchangeService service) { this.service = service; }

    @PostMapping(value = "/{prsCode}", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public JsonNode exchange(@PathVariable String prsCode, @RequestBody JsonNode request) {
        return service.exchange(prsCode, request);
    }
}
