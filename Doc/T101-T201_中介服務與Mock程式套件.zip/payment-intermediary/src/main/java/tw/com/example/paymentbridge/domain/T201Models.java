package tw.com.example.paymentbridge.domain;

import java.util.List;

public final class T201Models {
    private T201Models() { }

    public record PayHead(String pendingNo, String mFlag) { }
    public record PayDetail(String detailNo) { }
    public record RequestBody(PayHead PAYHEAD, List<PayDetail> PAYDETAIL) { }
    public record ResponseBody(Long totalAmount, Long totalFee) { }
}
