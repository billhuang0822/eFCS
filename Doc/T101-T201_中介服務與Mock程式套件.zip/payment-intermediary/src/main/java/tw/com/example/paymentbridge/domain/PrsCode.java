package tw.com.example.paymentbridge.domain;

public enum PrsCode {
    T101, T102, T112, T201;

    public static PrsCode parse(String value) {
        if (value == null) throw new IllegalArgumentException("prsCode is required");
        try { return valueOf(value.trim().toUpperCase()); }
        catch (IllegalArgumentException ex) { throw new IllegalArgumentException("Unsupported prsCode: " + value); }
    }
}
