package tw.com.example.paymentbridge.domain;

import java.util.List;

public final class T112Models {
    private T112Models() { }

    public record PayHead(String pendingNo, String pendingNotAfter,
            Long totalCount, Long totalAmount, String outBankId, String memberId,
            String outAccountNum, String payDatetime, String checkType,
            String billType, String deviceId, String carrierType,
            String carrierNo, String mobile) { }

    public record PayDetail(String detailNo, Long txnAmount,
            String billData, String billBatch) { }

    public record RequestBody(PayHead PAYHEAD, List<PayDetail> PAYDETAIL) { }
}
