package tw.com.example.paymentbridge.error;

public class ProtocolException extends RuntimeException {
    public ProtocolException(String message) { super(message); }
}
