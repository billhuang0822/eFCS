package tw.com.example.paymentbridge.domain;

public record MessageHead(
        String txnChannel,
        String prsCode,
        String txnDataTime,
        String txnNo,
        String billerId,
        String bTypeClass,
        String icChkCode,
        String icChkDesc) { }
