package tw.com.example.paymentbridge.client;

import com.fasterxml.jackson.databind.JsonNode;
import tw.com.example.paymentbridge.domain.PrsCode;

public interface ClearingGatewayClient {
    JsonNode exchange(PrsCode prsCode, JsonNode request);
}
