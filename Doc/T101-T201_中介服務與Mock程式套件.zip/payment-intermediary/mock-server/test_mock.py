#!/usr/bin/env python3
from http.server import ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import json, sys
sys.path.insert(0, str(Path(__file__).parent))
from server import Handler, ROOT

server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
Thread(target=server.serve_forever, daemon=True).start()
port = server.server_address[1]
try:
    for code in ("T101", "T102", "T112", "T201"):
        payload = (ROOT / "samples" / "requests" / f"{code}Request.json").read_bytes()
        req = Request(f"http://127.0.0.1:{port}/api/v1/messages/{code}", data=payload, headers={"Content-Type":"application/json"}, method="POST")
        with urlopen(req, timeout=5) as res:
            body = json.load(res)
            assert res.status == 200
            assert body["HEAD"]["prsCode"] == code
            assert body["HEAD"]["icChkCode"] == "0000"
            print(f"{code}: PASS")
    bad = json.loads((ROOT / "samples" / "requests" / "T102Request.json").read_text(encoding="utf-8"))
    bad["HEAD"]["prsCode"] = "T101"
    req = Request(f"http://127.0.0.1:{port}/api/v1/messages/T102",
                  data=json.dumps(bad).encode("utf-8"),
                  headers={"Content-Type":"application/json"}, method="POST")
    try:
        urlopen(req, timeout=5)
        raise AssertionError("mismatched prsCode should fail")
    except HTTPError as exc:
        assert exc.code == 400
        print("prsCode mismatch: PASS")
finally:
    server.shutdown(); server.server_close()
