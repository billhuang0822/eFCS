#!/usr/bin/env python3
"""Zero-dependency T101/T102/T112/T201 mock server for local integration tests."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from datetime import datetime
import argparse, json

ROOT = Path(__file__).resolve().parents[1]
SUPPORTED = {"T101", "T102", "T112", "T201"}
RESPONSES = {c: json.loads((ROOT / "samples" / "responses" / f"{c}Response.json").read_text(encoding="utf-8")) for c in SUPPORTED}

class Handler(BaseHTTPRequestHandler):
    server_version = "PaymentBridgeMock/1.0"

    def _send(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health": return self._send(200, {"status": "UP"})
        return self._send(404, {"code": "NOT_FOUND", "message": "Use POST /api/v1/messages/{prsCode}"})

    def do_POST(self):
        prefix = "/api/v1/messages/"
        code = self.path[len(prefix):].upper() if self.path.startswith(prefix) else ""
        if code not in SUPPORTED:
            return self._send(404, {"code": "UNSUPPORTED_PRS_CODE", "message": code or self.path})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            request = json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception as exc:
            return self._send(400, {"code": "INVALID_JSON", "message": str(exc)})
        head = request.get("HEAD")
        if not isinstance(head, dict):
            return self._send(400, {"code": "INVALID_MESSAGE", "message": "HEAD object is required"})
        if head.get("prsCode") != code:
            return self._send(400, {"code": "INVALID_MESSAGE", "message": f"Path {code} does not match HEAD.prsCode {head.get('prsCode')}"})
        if not isinstance(request.get("BODY"), dict):
            return self._send(400, {"code": "INVALID_MESSAGE", "message": "BODY object is required for requests"})
        response = json.loads(json.dumps(RESPONSES[code], ensure_ascii=False))
        response_head = response["HEAD"]
        for field in ("txnChannel", "txnNo", "billerId", "bTypeClass"):
            if field in head: response_head[field] = head[field]
        response_head.update(prsCode=code, txnDataTime=datetime.now().strftime("%Y%m%d%H%M%S"), icChkCode="0000", icChkDesc="SUCCESS")
        return self._send(200, response)

    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()
    print(f"Mock listening on http://{args.host}:{args.port}")
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()

if __name__ == "__main__": main()
